window.init_process = {
    env: {
        MIX_JS_ROUTE_PARAM_ATTR_KEY: '49C72148FE4F7',
        MIX_JS_ROUTE_PARAM_ATTR: 'data-kps',
    }
};